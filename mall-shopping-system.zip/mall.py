
# mall.py

class Mall:
    def __init__(self):
        self.products = {
            "Shoes": 1200,
            "T-Shirt": 700,
            "Jeans": 1500,
            "Watch": 2500,
            "Sunglasses": 800
        }
        self.cart = {}

    def display_products(self):
        print("\nAvailable Products:")
        for item, price in self.products.items():
            print(f"{item}: ₹{price}")

    def add_to_cart(self, item, quantity):
        if item in self.products:
            self.cart[item] = self.cart.get(item, 0) + quantity
            print(f"{item} added to cart.")
        else:
            print("Item not found.")

    def view_cart(self):
        if not self.cart:
            print("Your cart is empty.")
            return
        print("\nYour Cart:")
        total = 0
        for item, quantity in self.cart.items():
            price = self.products[item] * quantity
            print(f"{item} x {quantity} = ₹{price}")
            total += price
        print(f"Total Bill: ₹{total}")

def main():
    mall = Mall()
    while True:
        print("\n1. View Products\n2. Add to Cart\n3. View Cart\n4. Exit")
        choice = input("Enter choice: ")
        if choice == '1':
            mall.display_products()
        elif choice == '2':
            item = input("Enter product name: ")
            quantity = int(input("Enter quantity: "))
            mall.add_to_cart(item, quantity)
        elif choice == '3':
            mall.view_cart()
        elif choice == '4':
            print("Thank you for visiting the mall!")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
