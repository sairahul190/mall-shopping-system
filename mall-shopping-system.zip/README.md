
# 🛍️ Mall Shopping System (Python)

This is a simple **console-based mall shopping system** built using Python. It allows users to browse available products, add items to their cart, and view the total bill.

## 📌 Features

- View available products with prices
- Add items to shopping cart
- Calculate and display total bill
- Simple and beginner-friendly code

## 💻 Technologies Used

- Python 3

## 🚀 How to Run

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/mall-shopping-system.git
   cd mall-shopping-system
   ```

2. Run the program:
   ```bash
   python mall.py
   ```

## 🧾 Sample Output

```
1. View Products
2. Add to Cart
3. View Cart
4. Exit
Enter choice:
```

## 📂 File Structure

```
mall-shopping-system/
│
├── mall.py        # Main Python file
└── README.md      # Project documentation
```

## 📄 License

This project is open-source and available under the MIT License.

---

*Created for practice and learning purposes.*
